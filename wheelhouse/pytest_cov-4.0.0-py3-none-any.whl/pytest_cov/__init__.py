"""pytest-cov: avoid already-imported warning: PYTEST_DONT_REWRITE."""
__version__ = '4.0.0'
